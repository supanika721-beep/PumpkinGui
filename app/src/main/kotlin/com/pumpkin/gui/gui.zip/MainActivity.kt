package com.pumpkin.gui

import android.content.Intent
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import com.pumpkin.gui.databinding.ActivityMainBinding
import com.pumpkin.gui.service.ServerService
import com.pumpkin.gui.util.NetworkInfo
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        
        if (savedInstanceState == null) {
            navigateTo(ConsoleFragment(), "Console", binding.navConsole)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun setupNavigation() {
        binding.btnMenu.setOnClickListener { binding.drawerLayout.openDrawer(GravityCompat.START) }

        fun nav(frag: Fragment, title: String, navView: android.widget.TextView) {
            navigateTo(frag, title, navView)
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }

        binding.navConsole.setOnClickListener { nav(ConsoleFragment(), "Console", binding.navConsole) }
        binding.navFiles.setOnClickListener { nav(FilesFragment(), "Files", binding.navFiles) }
        binding.navConfig.setOnClickListener { nav(ConfigFragment(), "Config", binding.navConfig) }
        binding.navWorld.setOnClickListener { nav(WorldFragment(), "World", binding.navWorld) }
        binding.navNetwork.setOnClickListener { nav(NetworkFragment(), "Network", binding.navNetwork) }

        binding.tvTopBarLocalIp.text = "Local IP: ${NetworkInfo.getLocalIp()}"
    }

    private fun navigateTo(fragment: Fragment, title: String, activeNav: android.widget.TextView?) {
        binding.tvPageTitle.text = title
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commitAllowingStateLoss()

        val COLOR_ACTIVE = 0xFFF0F6FC.toInt()
        val COLOR_INACTIVE = 0xFF8B949E.toInt()

        listOf(binding.navConsole, binding.navFiles, binding.navConfig, binding.navWorld, binding.navNetwork).forEach { v ->
            v.setTextColor(if (v == activeNav) COLOR_ACTIVE else COLOR_INACTIVE)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
