package com.pumpkin.gui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import com.pumpkin.gui.databinding.ActivityMainBinding
import com.pumpkin.gui.util.NetworkInfo
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        // PASANG LOGGER DISINI (Sebelum super.onCreate agar mencakup semua bug UI/Siklus Hidup)
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            saveCrashLog(throwable)
        }

        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        
        if (savedInstanceState == null) {
            navigateTo(ConsoleFragment(), "Console", binding.navConsole)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun setupNavigation() {
        binding.btnMenu.setOnClickListener { binding.drawerLayout.openDrawer(GravityCompat.START) }

        fun nav(frag: Fragment, title: String, navView: android.widget.TextView) {
            navigateTo(frag, title, navView)
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }

        binding.navConsole.setOnClickListener { nav(ConsoleFragment(), "Console", binding.navConsole) }
        binding.navFiles.setOnClickListener { nav(FilesFragment(), "Files", binding.navFiles) }
        binding.navConfig.setOnClickListener { nav(ConfigFragment(), "Config", binding.navConfig) }
        binding.navWorld.setOnClickListener { nav(WorldFragment(), "World", binding.navWorld) }
        binding.navNetwork.setOnClickListener { nav(NetworkFragment(), "Network", binding.navNetwork) }

        // Mencegah NetworkOnMainThreadException potensial
        Thread {
            try {
                val ipText = "Local IP: ${NetworkInfo.getLocalIp()}"
                runOnUiThread { binding.tvTopBarLocalIp.text = ipText }
            } catch (_: Exception) {}
        }.start()
    } // <--- Tanda kurung kurawal ini tadi hilang/salah letak

    private fun navigateTo(fragment: Fragment, title: String, activeNav: android.widget.TextView?) {
        binding.tvPageTitle.text = title
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commitAllowingStateLoss()

        val COLOR_ACTIVE = 0xFFF0F6FC.toInt()
        val COLOR_INACTIVE = 0xFF8B949E.toInt()

        listOf(binding.navConsole, binding.navFiles, binding.navConfig, binding.navWorld, binding.navNetwork).forEach { v ->
            v.setTextColor(if (v == activeNav) COLOR_ACTIVE else COLOR_INACTIVE)
        }
    }

    // FUNGSI UNTUK MENULIS FILE LOG DAN TOAST
    private fun saveCrashLog(throwable: Throwable) {
        try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            
            // Lokasi penyimpanan file log: Android/data/com.pumpkin.gui/files/pumpkin_crash.txt
            val logDir = getExternalFilesDir(null)
            val logFile = File(logDir, "pumpkin_crash.txt")
            
            val writer = FileWriter(logFile, true)
            val printWriter = PrintWriter(writer)
            
            printWriter.println("\n================ CRASH LOG $timeStamp ================")
            throwable.printStackTrace(printWriter)
            printWriter.close()
            
            // Tampilkan Toast di Main Thread sebelum aplikasi mati total
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    applicationContext, 
                    "CRASH TERDETEKSI! Log disimpan di: ${logFile.absolutePath}", 
                    Toast.LENGTH_LONG
                ).show()
            }
            
            // Beri jeda 3 detik agar Toast sempat terbaca sebelum aplikasi keluar
            Thread.sleep(3000)
            
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            // Selesaikan proses penutupan aplikasi bawaan sistem android
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
