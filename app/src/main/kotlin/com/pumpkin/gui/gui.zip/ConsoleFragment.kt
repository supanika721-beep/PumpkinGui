package com.pumpkin.gui

import android.content.*
import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.pumpkin.gui.databinding.FragmentConsoleBinding
import com.pumpkin.gui.service.ServerService
import com.termux.terminal.TerminalSession
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient

class ConsoleFragment : Fragment() {

    private var _binding: FragmentConsoleBinding? = null
    private val binding get() = _binding!!

    private val tvClient = object : TerminalViewClient {
        override fun onScale(scale: Float): Float = scale
        override fun onSingleTapUp(e: MotionEvent) {}
        override fun shouldBackButtonBeMappedToEscape(): Boolean = false
        override fun shouldEnforceCharBasedInput(): Boolean = false
        override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
        override fun isTerminalViewSelected(): Boolean = true
        override fun copyModeChanged(copyMode: Boolean) {}
        override fun onKeyDown(keyCode: Int, e: KeyEvent, session: TerminalSession): Boolean = false
        override fun onKeyUp(keyCode: Int, e: KeyEvent): Boolean = false
        override fun onLongPress(event: MotionEvent): Boolean = false
        override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession): Boolean = false
        override fun readControlKey(): Boolean = false
        override fun readAltKey(): Boolean = false
        override fun readShiftKey(): Boolean = false
        override fun readFnKey(): Boolean = false
        override fun onEmulatorSet() {}
        override fun logError(tag: String, message: String) {}
        override fun logWarn(tag: String, message: String) {}
        override fun logInfo(tag: String, message: String) {}
        override fun logDebug(tag: String, message: String) {}
        override fun logVerbose(tag: String, message: String) {}
        override fun logStackTraceWithMessage(tag: String, message: String, e: Exception) {}
        override fun logStackTrace(tag: String, e: Exception) {}
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentConsoleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupTerminal()
        setupListeners()
        registerCallbacks()
        
        updateUIState(ServerService.isRunning)
    }

    private fun setupTerminal() {
        binding.terminalView.setTerminalViewClient(tvClient)
        binding.terminalView.setTextSize(14)
        
        ServerService.session?.let { 
            binding.terminalView.attachSession(it)
        }
    }

    private fun setupListeners() {
        binding.btnStartStop.setOnClickListener {
            val intent = Intent(requireContext(), ServerService::class.java)
            if (ServerService.isRunning) {
                intent.action = "STOP"
            } else {
                intent.action = "START"
            }
            requireContext().startService(intent)
        }

        binding.btnRestart.setOnClickListener {
            val intent = Intent(requireContext(), ServerService::class.java).apply { action = "RESTART" }
            requireContext().startService(intent)
        }

        binding.btnSend.setOnClickListener { sendCommand() }
        
        binding.etCommand.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendCommand()
                true
            } else false
        }

        binding.btnCopyLog.setOnClickListener {
            val session = ServerService.session
            if (session != null) {
                val text = session.emulator.screen.getSelectedText(0, 0, session.emulator.mRows, session.emulator.mColumns)
                val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Pumpkin Log", text))
                Toast.makeText(requireContext(), "Logs copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendCommand() {
        val cmd = binding.etCommand.text.toString()
        if (cmd.isNotBlank()) {
            ServerService.session?.write(cmd + "\n")
            binding.etCommand.text.clear()
        }
    }

    private fun registerCallbacks() {
        ServerService.onTerminalChanged = { session ->
            if (isAdded) {
                if (binding.terminalView.currentSession == null) {
                    binding.terminalView.attachSession(session)
                }
                binding.terminalView.post { binding.terminalView.invalidate() }
            }
        }

        ServerService.onStateChanged = { running ->
            if (isAdded) {
                updateUIState(running)
            }
        }

        ServerService.onStatsChanged = { cpu, ram ->
            if (isAdded) {
                binding.tvCpu.text = "${String.format("%.1f", cpu)}%"
                binding.progressCpu.progress = cpu.toInt()
                binding.tvRam.text = "$ram MB"
                binding.progressRam.progress = (ram / 10).toInt().coerceIn(0, 100)
            }
        }
    }

    private fun updateUIState(running: Boolean) {
        binding.btnStartStop.text = if (running) "STOP SERVER" else "START SERVER"
        binding.btnStartStop.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (running) resources.getColor(R.color.status_stopped) else resources.getColor(R.color.status_running)
        )
        if (!running) {
            binding.tvCpu.text = "0%"
            binding.progressCpu.progress = 0
            binding.tvRam.text = "0 MB"
            binding.progressRam.progress = 0
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        ServerService.onTerminalChanged = null
        ServerService.onStateChanged = null
        ServerService.onStatsChanged = null
        _binding = null
    }
}
