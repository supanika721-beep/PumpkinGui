package com.pumpkin.gui.service

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Field

class ServerService : Service() {

    companion object {
        const val CHANNEL_ID = "pumpkin_server_v4"
        const val NOTIF_ID    = 101

        var isRunning  = false
        var isStopping = false
        var session: TerminalSession? = null

        // Callbacks for UI
        var onTerminalChanged: ((TerminalSession) -> Unit)? = null
        var onStateChanged:    ((Boolean) -> Unit)? = null
        var onStatsChanged:    ((Float, Long) -> Unit)? = null
        var onPlayersChanged:  ((List<String>) -> Unit)? = null
        var onCrashed:         ((Int) -> Unit)? = null
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Server is starting..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP"    -> stopServer()
            "RESTART" -> { stopServer(); startServer() }
            else      -> if (!isRunning) startServer()
        }
        return START_STICKY
    }

    private fun startServer() {
        if (isRunning) return
        isRunning = true
        isStopping = false
        
        serviceScope.launch {
            try {
                val binPath = prepareBinary()
                val workDir = filesDir.absolutePath
                
                val env = arrayOf(
                    "HOME=$workDir",
                    "TMPDIR=$cacheDir",
                    "TERM=xterm-256color"
                )

                val client = object : TerminalSessionClient {
                    override fun onTextChanged(changedSession: TerminalSession) {
                        serviceScope.launch(Dispatchers.Main) {
                            onTerminalChanged?.invoke(changedSession)
                        }
                    }
                    override fun onSessionFinished(finishedSession: TerminalSession) {
                        val exitCode = finishedSession.exitStatus
                        serviceScope.launch(Dispatchers.Main) {
                            isRunning = false
                            onStateChanged?.invoke(false)
                            if (exitCode != 0 && !isStopping) onCrashed?.invoke(exitCode)
                            stopSelf()
                        }
                    }
                    override fun onTitleChanged(s: TerminalSession) {}
                    override fun onCopyTextToClipboard(s: TerminalSession, t: String) {}
                    override fun onPasteTextFromClipboard(s: TerminalSession) {}
                    override fun onBell(s: TerminalSession) {}
                    override fun onColorsChanged(s: TerminalSession) {}
                    override fun onTerminalCursorStateChange(b: Boolean) {}
                    override fun getTerminalCursorStyle(): Int = 0
                    override fun logError(t: String, m: String) {}
                    override fun logWarn(t: String, m: String) {}
                    override fun logInfo(t: String, m: String) {}
                    override fun logDebug(t: String, m: String) {}
                    override fun logVerbose(t: String, m: String) {}
                    override fun logStackTraceWithMessage(t: String, m: String, e: Exception) {}
                    override fun logStackTrace(t: String, e: Exception) {}
                }

                session = TerminalSession(
                    binPath, workDir, arrayOf(), env, null, client
                )

                serviceScope.launch(Dispatchers.Main) {
                    onStateChanged?.invoke(true)
                    updateNotification("Server is running")
                }
                
                startMonitoring()

            } catch (e: Exception) {
                isRunning = false
                serviceScope.launch(Dispatchers.Main) { onStateChanged?.invoke(false) }
                stopSelf()
            }
        }
    }

    private fun stopServer() {
        isStopping = true
        session?.finishIfRunning()
        isRunning = false
        monitorJob?.cancel()
        onStateChanged?.invoke(false)
        stopSelf()
    }

    private fun prepareBinary(): String {
        val is64 = Build.SUPPORTED_ABIS.contains("arm64-v8a")
        val resId = if (is64) com.pumpkin.gui.R.raw.arm64 else com.pumpkin.gui.R.raw.arm32
        val outFile = File(filesDir, "pumpkin_bin")
        
        resources.openRawResource(resId).use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
        outFile.setExecutable(true)
        return outFile.absolutePath
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            while (isActive && isRunning) {
                val pid = getSessionPid()
                if (pid > 0) {
                    val cpu = readCpu(pid)
                    val ram = readRam(pid)
                    withContext(Dispatchers.Main) {
                        onStatsChanged?.invoke(cpu, ram)
                    }
                }
                delay(2000)
            }
        }
    }

    private fun getSessionPid(): Int {
        return try {
            val f: Field = TerminalSession::class.java.getDeclaredField("mShellPid")
            f.isAccessible = true
            f.getInt(session)
        } catch (e: Exception) { -1 }
    }

    private fun readCpu(pid: Int): Float {
        // Simplified CPU read for now, can be expanded
        return 0f 
    }

    private fun readRam(pid: Int): Long {
        return try {
            val stat = File("/proc/$pid/status").readLines()
            val rssLine = stat.find { it.startsWith("VmRSS:") }
            rssLine?.split("\\s+".toRegex())?.get(1)?.toLong()?.div(1024) ?: 0L
        } catch (e: Exception) { 0L }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Pumpkin Server", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, com.pumpkin.gui.MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pumpkin Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
