package com.pumpkin.gui.service

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Field

class ServerService : Service() {

    companion object {
        const val CHANNEL_ID = "pumpkin_server_v4"
        const val NOTIF_ID    = 101

        var isRunning  = false
        var isStopping = false
        var session: TerminalSession? = null

        // Callbacks for UI
        var onTerminalChanged: ((TerminalSession) -> Unit)? = null
        var onStateChanged:    ((Boolean) -> Unit)? = null
        var onStatsChanged:    ((Float, Long) -> Unit)? = null
        var onPlayersChanged:  ((List<String>) -> Unit)? = null
        var onCrashed:         ((Int) -> Unit)? = null
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Server is starting..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP"    -> stopServer()
            "RESTART" -> { stopServer(); startServer() }
            else      -> if (!isRunning) startServer()
        }
        return START_STICKY
    }

    private fun startServer() {
        if (isRunning) return
        isRunning = true
        isStopping = false
        
        serviceScope.launch {
            try {
                // Menyiapkan biner di background thread (IO)
                val binPath = prepareBinary()
                
                // Menggunakan properti bawaan Context Android secara dinamis dan aman
                val workDir = filesDir.absolutePath
                val tempDir = cacheDir.absolutePath
                
                val env = arrayOf(
                    "HOME=$workDir",
                    "TMPDIR=$tempDir",
                    "TERM=xterm-256color"
                )

                // Kembali menginduk ke TerminalSessionClient bawaan Termux
                val client = object : TerminalSessionClient {
                    
                    override fun getTerminalCursorStyle(): Int = 0

                    override fun onTextChanged(changedSession: TerminalSession) {
                        serviceScope.launch(Dispatchers.Main) {
                            onTerminalChanged?.invoke(changedSession)
                        }
                    }

                    override fun onSessionFinished(finishedSession: TerminalSession) {
                        val exitCode = finishedSession.exitStatus
                        if (exitCode != 0) {
                            saveBinaryErrorLog(exitCode)
                        }
                        serviceScope.launch(Dispatchers.Main) {
                            isRunning = false
                            onStateChanged?.invoke(false)
                            if (exitCode != 0 && !isStopping) onCrashed?.invoke(exitCode)
                            stopSelf()
                        }
                    }

                    // Sisa fungsi wajib lainnya di bawah ini biarkan tetap seperti kode aslimu:
                    override fun onTitleChanged(s: TerminalSession) {}
                    override fun onCopyTextToClipboard(s: TerminalSession, t: String) {}
                    override fun onPasteTextFromClipboard(s: TerminalSession) {}
                    override fun onBell(s: TerminalSession) {}
                    override fun onColorsChanged(s: TerminalSession) {}
                    override fun onTerminalCursorStateChange(b: Boolean) {}
                    override fun logError(t: String, m: String) {}
                    override fun logWarn(t: String, m: String) {}
                    override fun logInfo(t: String, m: String) {}
                    override fun logDebug(t: String, m: String) {}
                    override fun logVerbose(t: String, m: String) {}
                    override fun logStackTraceWithMessage(t: String, m: String, e: Exception) {}
                    override fun logStackTrace(t: String, e: Exception) {}
                }


                // Dialihkan ke Main Thread agar tidak memicu error Looper.prepare()
                withContext(Dispatchers.Main) {
                    session = TerminalSession(
                        binPath, workDir, arrayOf(), env, null, client
                    )

                    onStateChanged?.invoke(true)
                    updateNotification("Server is running")
                }
                
                startMonitoring()

            } catch (e: Exception) {
                isRunning = false
                // Logger tetap aktif memantau jika ada kendala lain
                saveCustomErrorLog("Gagal saat inisialisasi Server: ${e.message}\n${android.util.Log.getStackTraceString(e)}")
                serviceScope.launch(Dispatchers.Main) { onStateChanged?.invoke(false) }
                stopSelf()
            }
        }
    }

    private fun stopServer() {
        isStopping = true
        session?.finishIfRunning()
        isRunning = false
        monitorJob?.cancel()
        onStateChanged?.invoke(false)
        stopSelf()
    }

    private fun prepareBinary(): String {
        val is64 = Build.SUPPORTED_ABIS.contains("arm64-v8a")
        val resId = if (is64) com.pumpkin.gui.R.raw.arm64 else com.pumpkin.gui.R.raw.arm32
        val outFile = File(filesDir, "pumpkin")
        
        resources.openRawResource(resId).use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
        outFile.setExecutable(true)
        return outFile.absolutePath
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            while (isActive && isRunning) {
                val pid = getSessionPid()
                if (pid > 0) {
                    val cpu = readCpu(pid)
                    val ram = readRam(pid)
                    withContext(Dispatchers.Main) {
                        onStatsChanged?.invoke(cpu, ram)
                    }
                }
                delay(2000)
            }
        }
    }

    private fun getSessionPid(): Int {
        return try {
            val f: Field = TerminalSession::class.java.getDeclaredField("mShellPid")
            f.isAccessible = true
            f.getInt(session)
        } catch (e: Exception) { -1 }
    }

    private fun readCpu(pid: Int): Float {
        val CLK_TCK = 100L
        return try {
            val raw    = File("/proc/$pid/stat").readText()
            val fields = raw.substringAfterLast(')').trim().split("\\s+".toRegex())
            if (fields.size < 13) return 0f
            val ticks  = (fields[11].toLongOrNull() ?: 0L) + (fields[12].toLongOrNull() ?: 0L)
            val nowMs  = android.os.SystemClock.elapsedRealtime()
            val dTicks = ticks - lastProcTicks
            val dMs    = nowMs - lastMonitorTime
            lastProcTicks   = ticks
            lastMonitorTime = nowMs
            if (lastMonitorTime == 0L || dMs <= 0L || dTicks < 0L) return 0f
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            (dTicks.toFloat() / ((dMs / 1000f) * CLK_TCK * cores) * 100f).coerceIn(0f, 100f)
        } catch (_: Exception) { 0f }
    }

    private fun readRam(pid: Int): Long {
        return try {
            val stat = File("/proc/$pid/status").readLines()
            val rssLine = stat.find { it.startsWith("VmRSS:") }
            rssLine?.split("\\s+".toRegex())?.get(1)?.toLong()?.div(1024) ?: 0L
        } catch (e: Exception) { 0L }
    }
    
        // LANGKAH 1: Fungsi untuk mencatat kode error dari biner secara otomatis
    private fun saveBinaryErrorLog(exitCode: Int) {
        try {
            val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
            val logFile = File(getExternalFilesDir(null), "pumpkin_crash.txt")
            val writer = java.io.FileWriter(logFile, true)
            val printWriter = java.io.PrintWriter(writer)
            
            printWriter.println("\n================ BINER EXIT DETECTED $timeStamp ================")
            printWriter.println("Server Biner berhenti mendadak dengan Exit Code: $exitCode")
            if (exitCode == 127) {
                printWriter.println("Analisis: Kemungkinan file biner korup atau dependensi linker (.so) hilang.")
            } else if (exitCode == 126) {
                printWriter.println("Analisis: Permission Denied! Masalah eksekusi biner di penyimpanan lokal.")
            }
            printWriter.close()
        } catch (_: Exception) {}
    }

    // Fungsi untuk mencatat error penyiapan/sistem service
    private fun saveCustomErrorLog(message: String) {
        try {
            val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
            val logFile = File(getExternalFilesDir(null), "pumpkin_crash.txt")
            val writer = java.io.FileWriter(logFile, true)
            writer.write("\n================ SERVICE ERROR $timeStamp ================\n$message\n")
            writer.close()
        } catch (_: Exception) {}
    }


    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Pumpkin Server", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, ServerService::class.java).apply { action = "STOP" },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val restartPi = PendingIntent.getService(this, 2,
            Intent(this, ServerService::class.java).apply { action = "RESTART" },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎃 Pumpkin Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "⏹ Stop", stopPi)
            .addAction(android.R.drawable.ic_media_rew, "↺ Restart", restartPi)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
